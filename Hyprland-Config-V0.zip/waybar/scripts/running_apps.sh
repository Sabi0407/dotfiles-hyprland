#!/bin/bash
ps -e -o cmd | grep -E 'discord|Telegram|steam|spotify|signal|slack|teams|skype|obsidian|thunderbird|element|zoom|chromium|firefox|brave|vivaldi' | grep -v grep | sort | uniq 